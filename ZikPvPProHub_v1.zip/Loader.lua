
local Settings = {
    JoinTeam = "Pirates", -- Bisa diganti "Marines"
    Translator = true
}

loadstring(game:HttpGet("https://raw.githubusercontent.com/Zikhubdev/ZikPvPPro/main/MainUI.lua"))(Settings)
